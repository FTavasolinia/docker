# django-crud-sample
Django user CRUD API example project with Postgres
